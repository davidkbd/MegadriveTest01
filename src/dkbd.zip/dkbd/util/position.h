#include <genesis.h>

BORRAMEEEEEEEEEEEEEEEEEEEEEEEE

#include "vector2.h"
#include "rect.h"

u8 position_isRectInRect(Rect *rect1, Rect *rect2);
u8 position_isInRect(Vector2 *pos, Rect *rect);

