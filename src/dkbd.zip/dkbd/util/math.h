#include <genesis.h>

s32 math_pow(u8 times, s32 number);

