#include <genesis.h>

u32 string_strToU32(u8 *str);
u8 string_length(u8* str);

