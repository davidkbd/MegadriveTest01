#include <genesis.h>

#ifndef MAP_ONTOP_
#define MAP_ONTOP_

const u8 map_ontop[160] = {
0
};

#endif

