// TITLE
#define SFX_START        64

// MENU
#define SFX_SELECT       65
#define SFX_CHANGE       66
#define SFX_CHANGE_WRONG 67

// INGAME
#define SFX_FIRE         65
#define SFX_RING         66
#define SFX_RINGLOST     67
