#include <genesis.h>

/**
 * Fija fps
 */
void fpsfixer_fixTo30FPS(u32 initialFrameTimeMillis);
