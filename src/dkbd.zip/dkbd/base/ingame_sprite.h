#include <genesis.h>

#include "../util/vector2.h"
#include "../util/rect.h"

#ifndef INGAMESPRITE_H_
#define INGAMESPRITE_H_

struct IngameSprite_st {
	// Datos del sprite fijados en sprite.res
	const SpriteDefinition *spriteDef;
	// Es un objeto fijado al mapa, no se mueve
	u8 isStatic;
	// Id de paleta a utilizar al crear
	u8 palette;
	// En principio siempre es false, el hud es el que tiene que estar siempre on top
	u8 alwaysOnTop;
	// Instancia del sprite
	Sprite* sprite;
	// Posicion absoluta
	Vector2 position;
	// Posicion respecto al viewport
	Vector2 posInViewport;
	// Velocidad de movimiento
	Vector2 speed;
	// Utilizado para saber si cargar o destruir al hacer scroll
	Vector2 size;
	// La mitad de size.x, precalculado
	u8 xCenter;
	// Tocando suelo
	u8 onFloor;
	// Al borde de una plataforma
	s8 onPlatformBorder;
	// Empujando
	s8 pushing;
	// Colisionador global
	Rect collider;
	// Colisionador de los pies
	Rect footsCollider;
	//0xFFFF
	u16 data;
	//Callback de actualizacion
	void (*update)(struct IngameSprite_st *sprite);
};
typedef struct IngameSprite_st IngameSprite;
#endif

void ingameSprite_moveTo(IngameSprite *sprite, s16 x, s16 y);
void ingameSprite_moveX(IngameSprite *sprite, s16 x);
void ingameSprite_moveY(IngameSprite *sprite, s16 y);
u8 ingameSprite_isEnabled(IngameSprite *sprite);
u8 ingameSprite_isDisabled(IngameSprite *sprite);
void ingameSprite_applyPosition(IngameSprite *sprite);
s8 ingameSprite_compareXPosition(IngameSprite *sprite1, IngameSprite *sprite2);
void ingameSprite_updatePosInViewport(IngameSprite *sprite);
void ingameSprite_enableOrDisableByViewport(IngameSprite *sprite);

