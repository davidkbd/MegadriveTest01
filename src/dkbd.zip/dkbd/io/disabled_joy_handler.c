#include <genesis.h>

void disabledJoyHandler(u16 joy, u16 changed, u16 state) {
	// DO NOTHING...
}
