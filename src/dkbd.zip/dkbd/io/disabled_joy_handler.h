#include <genesis.h>

/**
 * Esto sirve para bloquear los controles
 */
void disabledJoyHandler(u16 joy, u16 changed, u16 state);
