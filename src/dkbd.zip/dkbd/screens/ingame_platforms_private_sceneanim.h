#include <genesis.h>

#include "ingame_platforms_private.h"

void ingamePlatforms_updateSceneAnimation();

