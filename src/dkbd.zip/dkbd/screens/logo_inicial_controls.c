#include "logo_inicial.h"
#include "logo_inicial_private.h"

void logoInicial_onKeyPressFunction(u16 key) {
	logoInicial_beginExit();
}

void logoInicial_onKeyReleaseFunction(u16 key) {
}
