#include <genesis.h>

/**
 * Update de loop.
 */
void portada_update();

/**
 * Inicializacion
 */
void portada_initialize();

/**
 * Callback de controles
 */
void portada_onKeyPressFunction(u16);

/**
 * Callback de controles
 */
void portada_onKeyReleaseFunction(u16);
