#include <genesis.h>

#include "ingame_platforms_private.h"

void ingamePlatforms_onInanimatedUpdate(IngameSprite *s);

void ingamePlatforms_onJumperUpdate(IngameSprite *s);
