#include <genesis.h>

/**
 * Update de loop.
 */
void logoInicial_update();

/**
 * Inicializacion
 */
void logoInicial_initialize();

/**
 * Callback de controles
 */
void logoInicial_onKeyPressFunction(u16);

/**
 * Callback de controles
 */
void logoInicial_onKeyReleaseFunction(u16);
